
-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
CREATE TABLE IF NOT EXISTS `offers` (
  `brand` text COLLATE utf8_persian_ci,
  `offer` text COLLATE utf8_persian_ci,
  `place` text COLLATE utf8_persian_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`brand`, `offer`, `place`) VALUES
('1', '2', '3'),
('4', '5', '6');
