
-- --------------------------------------------------------

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
CREATE TABLE IF NOT EXISTS `service` (
  `id_cust` int(11) NOT NULL AUTO_INCREMENT,
  `number` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`id_cust`),
  UNIQUE KEY `id_cust` (`id_cust`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id_cust`, `number`) VALUES
(1, '1'),
(5, '09359325492'),
(6, '093593593259');
